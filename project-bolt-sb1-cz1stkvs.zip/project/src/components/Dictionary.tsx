import { useMemo, useState } from 'react';
import { Bookmark, Share2, Clock, Newspaper, BookOpen } from 'lucide-react';
import type { DictEntry, Category } from '@/types';

interface DictionaryProps {
  items: DictEntry[];
  bookmarkedIds: Set<string>;
  onToggleBookmark: (id: string) => void;
  onOpen: (item: DictEntry) => void;
  searchQuery: string;
}

type Filter = 'すべて' | Category | 'お気に入り';

const filters: Filter[] = ['すべて', '基礎', 'ビジネス', '技術トレンド', 'お気に入り'];

const categoryStyle: Record<Category, string> = {
  '基礎': 'border-sand-300/20 text-sand-200 bg-sand-300/5',
  'ビジネス': 'border-emerald-400/20 text-emerald-300/90 bg-emerald-400/5',
  '技術トレンド': 'border-sky-400/20 text-sky-300/90 bg-sky-400/5',
};

function shareOnX(title: string, url?: string) {
  const text = encodeURIComponent(`${title} #1分AIニュース`);
  const shareUrl = url ? `&url=${encodeURIComponent(url)}` : '';
  window.open(`https://twitter.com/intent/tweet?text=${text}${shareUrl}`, '_blank', 'noopener,noreferrer');
}

export function Dictionary({
  items,
  bookmarkedIds,
  onToggleBookmark,
  onOpen,
  searchQuery,
}: DictionaryProps) {
  const [activeFilter, setActiveFilter] = useState<Filter>('すべて');

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesQuery =
        !q ||
        item.title.toLowerCase().includes(q) ||
        (item.reading?.includes(q) ?? false) ||
        item.summary.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);

      let matchesFilter = true;
      if (activeFilter === 'お気に入り') {
        matchesFilter = bookmarkedIds.has(item.id);
      } else if (activeFilter !== 'すべて') {
        matchesFilter = item.category === activeFilter;
      }

      return matchesQuery && matchesFilter;
    });
  }, [items, activeFilter, searchQuery, bookmarkedIds]);

  return (
    <section id="dictionary" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-xs font-medium tracking-[0.2em] uppercase text-sand-100/40">Dictionary</span>
        <div className="divider flex-1" />
      </div>

      <h2 className="font-display text-2xl sm:text-3xl font-medium text-sand-100 mb-2">
        AI用語＆ニュース辞書
      </h2>
      <p className="text-sm text-sand-100/40 mb-8">
        基礎から最新技術まで。カードをタップして詳細を読む。
      </p>

      {/* フィルター */}
      <div className="flex flex-wrap gap-2 mb-8">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all border ${
              activeFilter === f
                ? 'bg-sand-100 text-ink-900 border-sand-100'
                : 'border-line text-sand-100/60 hover:text-sand-100 hover:border-line-hover'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Bento Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-20 text-sand-100/30">
          <p className="text-sm">該当する記事が見つかりませんでした</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item, i) => {
            const isBookmarked = bookmarkedIds.has(item.id);
            return (
              <article
                key={item.id}
                className="card-surface p-5 flex flex-col animate-fade-up"
                style={{ animationDelay: `${Math.min(i * 0.05, 0.4)}s` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`badge border ${categoryStyle[item.category]}`}>
                      {item.category}
                    </span>
                    {item.type === 'news' ? (
                      <Newspaper className="w-3.5 h-3.5 text-sand-100/30" />
                    ) : (
                      <BookOpen className="w-3.5 h-3.5 text-sand-100/30" />
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleBookmark(item.id);
                      }}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                        isBookmarked
                          ? 'text-sand-200 bg-sand-300/10'
                          : 'text-sand-100/30 hover:text-sand-100 hover:bg-white/5'
                      }`}
                      aria-label="お気に入り"
                    >
                      <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        shareOnX(item.title, item.url);
                      }}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-sand-100/30 hover:text-sand-100 hover:bg-white/5 transition-colors"
                      aria-label="Xでシェア"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <button onClick={() => onOpen(item)} className="text-left flex-1">
                  <h3 className="font-display text-lg font-medium text-sand-100 leading-snug">
                    {item.title}
                  </h3>
                  {item.reading && (
                    <p className="text-xs text-sand-100/30 mt-0.5">{item.reading}</p>
                  )}
                  <p className="mt-3 text-sm text-sand-100/50 leading-relaxed line-clamp-3">
                    {item.summary}
                  </p>
                </button>

                <div className="mt-4 pt-3 border-t border-line flex items-center justify-between">
                  <span className="text-xs text-sand-100/30">
                    {item.type === 'news' ? `${item.source} · ${item.date}` : item.date}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-sand-100/30">
                    <Clock className="w-3 h-3" /> {item.readTime}
                  </span>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
