import { Clock, ArrowUpRight } from 'lucide-react';
import type { DictEntry } from '@/types';
import { pickupImage } from '@/data';

interface PickupProps {
  item: DictEntry;
  onOpen: (item: DictEntry) => void;
}

export function Pickup({ item, onOpen }: PickupProps) {
  return (
    <section id="pickup" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-xs font-medium tracking-[0.2em] uppercase text-sand-100/40">Today's Pickup</span>
        <div className="divider flex-1" />
      </div>

      <button
        onClick={() => onOpen(item)}
        className="group block w-full text-left card-surface overflow-hidden"
      >
        <div className="grid md:grid-cols-2 gap-0">
          {/* 画像 */}
          <div className="relative aspect-[16/10] md:aspect-auto overflow-hidden bg-ink-800">
            <img
              src={pickupImage}
              alt="Today's pickup"
              className="w-full h-full object-cover opacity-80 group-hover:opacity-90 group-hover:scale-[1.02] transition-all duration-700"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-900/60 via-transparent to-transparent" />
          </div>

          {/* テキスト */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="badge bg-sand-300/10 text-sand-200 border border-sand-300/20">
                  {item.category}
                </span>
                <span className="flex items-center gap-1 text-xs text-sand-100/40">
                  <Clock className="w-3 h-3" /> {item.readTime}
                </span>
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-medium text-sand-100 leading-tight">
                {item.title}
              </h2>
              <p className="mt-4 text-sm text-sand-100/50 leading-relaxed line-clamp-4">
                {item.summary}
              </p>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <span className="text-xs text-sand-100/40">
                {item.source} · {item.date}
              </span>
              <span className="flex items-center gap-1 text-sm text-sand-200 group-hover:gap-2 transition-all">
                記事を読む <ArrowUpRight className="w-4 h-4" />
              </span>
            </div>
          </div>
        </div>
      </button>
    </section>
  );
}
