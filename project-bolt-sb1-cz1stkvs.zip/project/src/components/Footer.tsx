import { Sparkles } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-line bg-ink-900">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-12">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg border border-line flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-sand-200" />
            </div>
            <div>
              <p className="font-display text-base text-sand-100 tracking-wide">1分AI</p>
              <p className="text-[10px] text-sand-100/30 tracking-widest uppercase">Knowledge Archive</p>
            </div>
          </div>
          <p className="text-xs text-sand-100/30">
            © 2026 1分AI — A demo microlearning experience.
          </p>
        </div>
      </div>
    </footer>
  );
}
