import { useEffect } from 'react';
import { X, Bookmark, Share2, Clock } from 'lucide-react';
import type { DictEntry } from '@/types';

interface DetailModalProps {
  item: DictEntry | null;
  onClose: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
}

function shareOnX(title: string, url?: string) {
  const text = encodeURIComponent(`${title} #1分AIニュース`);
  const shareUrl = url ? `&url=${encodeURIComponent(url)}` : '';
  window.open(`https://twitter.com/intent/tweet?text=${text}${shareUrl}`, '_blank', 'noopener,noreferrer');
}

export function DetailModal({ item, onClose, isBookmarked, onToggleBookmark }: DetailModalProps) {
  useEffect(() => {
    if (!item) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [item, onClose]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm" />

      <div
        className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto card-surface animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ヘッダー */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-ink-850/95 backdrop-blur border-b border-line">
          <span className="badge border border-sand-300/20 text-sand-200 bg-sand-300/5">
            {item.category}
          </span>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-sand-100/50 hover:text-sand-100 hover:bg-white/5 transition-colors"
            aria-label="閉じる"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 本文 */}
        <div className="px-6 sm:px-8 py-6">
          <h2 className="font-display text-2xl sm:text-3xl font-medium text-sand-100 leading-tight">
            {item.title}
          </h2>
          {item.reading && (
            <p className="text-sm text-sand-100/30 mt-1">{item.reading}</p>
          )}

          <div className="mt-4 flex items-center gap-4 text-xs text-sand-100/40">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" /> {item.readTime}
            </span>
            {item.source && <span>{item.source}</span>}
            <span>{item.date}</span>
          </div>

          <div className="divider my-6" />

          {item.image && (
            <div className="mb-6 rounded-xl overflow-hidden border border-line">
              <img
                src={item.image}
                alt={item.title}
                className="w-full aspect-[16/9] object-cover opacity-80"
                loading="lazy"
              />
            </div>
          )}

          <p className="text-sm text-sand-100/70 leading-relaxed whitespace-pre-line">
            {item.description}
          </p>

          {item.example && (
            <div className="mt-6 rounded-xl border border-line bg-ink-800/50 px-4 py-3">
              <p className="text-xs font-semibold text-sand-100/40 mb-1 tracking-wide uppercase">Example</p>
              <p className="text-sm text-sand-100/60">{item.example}</p>
            </div>
          )}

          {/* アクション */}
          <div className="mt-8 flex items-center gap-3">
            <button
              onClick={() => onToggleBookmark(item.id)}
              className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium border transition-all ${
                isBookmarked
                  ? 'border-sand-300/30 bg-sand-300/10 text-sand-200'
                  : 'border-line text-sand-100/60 hover:text-sand-100 hover:border-line-hover'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
              {isBookmarked ? '保存済み' : '保存する'}
            </button>
            <button
              onClick={() => shareOnX(item.title, item.url)}
              className="inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium border border-line text-sand-100/60 hover:text-sand-100 hover:border-line-hover transition-all"
            >
              <Share2 className="w-4 h-4" /> Xでシェア
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
