import { Search } from 'lucide-react';

interface HeroProps {
  onSearch: (query: string) => void;
}

export function Hero({ onSearch }: HeroProps) {
  const today = new Date().toLocaleDateString('ja-JP', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });

  return (
    <section id="top" className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-ink-900" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 -z-10 w-[800px] h-[400px] rounded-full bg-sand-500/[0.03] blur-3xl" />

      <div className="mx-auto max-w-6xl px-4 sm:px-6 pt-20 pb-16 sm:pt-28 sm:pb-20">
        <div className="animate-fade-up">
          <span className="text-xs font-medium tracking-[0.2em] uppercase text-sand-100/40">
            {today} — Daily Edition
          </span>

          <h1 className="mt-6 font-display text-4xl sm:text-6xl lg:text-7xl font-medium tracking-tight text-sand-100 leading-[1.1]">
            1日1分、
            <br />
            <span className="text-sand-200">先端知識を蓄積する</span>
          </h1>

          <p className="mt-6 text-sm sm:text-base text-sand-100/50 max-w-md leading-relaxed">
            最新のAIニュースを1分で読める要約で。
            <br />
           基礎から最新技術まで、美しく整えられた辞書で。
          </p>
        </div>

        {/* 検索バー */}
        <div className="mt-10 animate-fade-up" style={{ animationDelay: '0.15s' }}>
          <div className="relative max-w-xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-[18px] h-[18px] text-sand-100/30" />
            <input
              type="text"
              onChange={(e) => onSearch(e.target.value)}
              placeholder="用語・ニュースを検索…"
              className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-ink-850 border border-line text-sand-100 placeholder:text-sand-100/30 focus:outline-none focus:border-line-hover transition-colors text-sm"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
