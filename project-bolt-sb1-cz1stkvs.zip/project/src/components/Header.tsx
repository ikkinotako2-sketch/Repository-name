import { Bookmark, Search, Sparkles } from 'lucide-react';

interface HeaderProps {
  onOpenSearch: () => void;
  onShowBookmarks: () => void;
  bookmarkCount: number;
}

export function Header({ onOpenSearch, onShowBookmarks, bookmarkCount }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl bg-ink-900/80 border-b border-line">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg border border-line flex items-center justify-center group-hover:border-line-hover transition-colors">
            <Sparkles className="w-4 h-4 text-sand-200" />
          </div>
          <div className="leading-tight">
            <p className="font-display text-lg text-sand-100 tracking-wide">1分AI</p>
            <p className="text-[10px] text-sand-100/40 tracking-widest uppercase">Knowledge Archive</p>
          </div>
        </a>

        <nav className="hidden md:flex items-center gap-1">
          <a href="#pickup" className="btn-ghost">Pickup</a>
          <a href="#dictionary" className="btn-ghost">Dictionary</a>
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSearch}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-sand-100/60 hover:text-sand-100 hover:bg-white/5 transition-colors"
            aria-label="検索"
          >
            <Search className="w-[18px] h-[18px]" />
          </button>
          <button
            onClick={onShowBookmarks}
            className="relative w-10 h-10 rounded-lg flex items-center justify-center text-sand-100/60 hover:text-sand-100 hover:bg-white/5 transition-colors"
            aria-label="お気に入り"
          >
            <Bookmark className="w-[18px] h-[18px]" />
            {bookmarkCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-sand-300 text-ink-900 text-[10px] font-bold flex items-center justify-center">
                {bookmarkCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
