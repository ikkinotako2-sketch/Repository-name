import { useCallback, useEffect, useState } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { Pickup } from '@/components/Pickup';
import { Dictionary } from '@/components/Dictionary';
import { DetailModal } from '@/components/DetailModal';
import { Footer } from '@/components/Footer';
import { entries } from '@/data';
import type { DictEntry } from '@/types';

const STORAGE_KEY = 'ai-dict-bookmarks';

function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return new Set(stored ? (JSON.parse(stored) as string[]) : []);
    } catch {
      return new Set();
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...bookmarks]));
  }, [bookmarks]);

  const toggle = useCallback((id: string) => {
    setBookmarks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  return { bookmarks, toggle };
}

function App() {
  const { bookmarks, toggle } = useBookmarks();
  const [searchQuery, setSearchQuery] = useState('');
  const [selected, setSelected] = useState<DictEntry | null>(null);

  const pickup = entries[0];
  const dictionaryItems = entries;

  return (
    <div className="min-h-screen bg-ink-900 text-sand-100">
      <Header
        onOpenSearch={() => {
          const el = document.getElementById('dictionary');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onShowBookmarks={() => {
          const el = document.getElementById('dictionary');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        bookmarkCount={bookmarks.size}
      />

      <main>
        <Hero onSearch={setSearchQuery} />
        <Pickup item={pickup} onOpen={setSelected} />
        <Dictionary
          items={dictionaryItems}
          bookmarkedIds={bookmarks}
          onToggleBookmark={toggle}
          onOpen={setSelected}
          searchQuery={searchQuery}
        />
      </main>

      <Footer />

      <DetailModal
        item={selected}
        onClose={() => setSelected(null)}
        isBookmarked={selected ? bookmarks.has(selected.id) : false}
        onToggleBookmark={toggle}
      />
    </div>
  );
}

export default App;
