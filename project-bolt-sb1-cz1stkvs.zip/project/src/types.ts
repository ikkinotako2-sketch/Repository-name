export type Category = '基礎' | 'ビジネス' | '技術トレンド';

export type EntryType = 'news' | 'term';

export interface DictEntry {
  id: string;
  type: EntryType;
  title: string;
  reading?: string;
  summary: string;
  description: string;
  category: Category;
  source?: string;
  date?: string;
  readTime?: string;
  url?: string;
  image?: string;
  example?: string;
}
